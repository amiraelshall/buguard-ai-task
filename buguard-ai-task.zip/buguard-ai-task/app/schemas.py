from pydantic import BaseModel
from typing import List, Optional

class AssetBase(BaseModel):
    id: str
    name: str
    type: str
    environment: str
    criticality: str

class AssetCreate(AssetBase):
    dependencies: Optional[List[str]] = []

class AssetResponse(AssetBase):
    dependencies: List[str] = []

    class Config:
        orm_mode = True