from sqlalchemy.orm import Session
from . import models, schemas

def import_bulk_assets(db: Session, payload: list[schemas.AssetCreate]) -> int:
    inserted_count = 0
    allowed_fields = {"id", "name", "type", "environment", "criticality"}
    
    for asset_schema in payload:
        asset_data = asset_schema.dict()
        dependencies = asset_data.pop("dependencies", [])
        asset_id = asset_data.get("id")
        
        filtered_data = {k: v for k, v in asset_data.items() if k in allowed_fields}
        existing_asset = db.query(models.Asset).filter(models.Asset.id == asset_id).first()
        
        if existing_asset:
            for key, value in filtered_data.items():
                setattr(existing_asset, key, value)
        else:
            new_asset = models.Asset(**filtered_data)
            db.add(new_asset)
            inserted_count += 1
            
    db.commit()

    for asset_schema in payload:
        asset_data = asset_schema.dict()
        dependencies = asset_data.get("dependencies", [])
        asset_id = asset_data.get("id")
        
        if dependencies:
            current_asset = db.query(models.Asset).filter(models.Asset.id == asset_id).first()
            if current_asset:
                dep_assets = db.query(models.Asset).filter(models.Asset.id.in_(dependencies)).all()
                current_asset.dependencies = dep_assets

    db.commit()
    return inserted_count