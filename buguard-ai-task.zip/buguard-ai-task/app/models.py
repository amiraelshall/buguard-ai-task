from sqlalchemy import Column, String, ForeignKey, Table
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()

# 1. Association table for self-referential many-to-many relationship
asset_relationship = Table(
    "asset_relationship",
    Base.metadata,
    Column("parent_id", String, ForeignKey("assets.id", ondelete="CASCADE"), primary_key=True),
    Column("child_id", String, ForeignKey("assets.id", ondelete="CASCADE"), primary_key=True),
)

# 2. Main Asset Model
class Asset(Base):
    __tablename__ = "assets"

    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
    type = Column(String, nullable=False)
    environment = Column(String, nullable=False)
    criticality = Column(String, nullable=False)

    # Many-to-many relationship to self
    dependencies = relationship(
        "Asset",
        secondary=asset_relationship,
        primaryjoin=id == asset_relationship.c.parent_id,
        secondaryjoin=id == asset_relationship.c.child_id,
        backref="required_by",
    )