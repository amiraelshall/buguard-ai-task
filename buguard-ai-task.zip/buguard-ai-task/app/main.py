from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from . import models, schemas, utils
from .database import engine, get_db


models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Asset Management & Graph Service")

@app.post("/api/v1/assets/import", status_code=201)
def import_assets(payload: List[schemas.AssetCreate], db: Session = Depends(get_db)):
    try:
        inserted_count = utils.import_bulk_assets(db, payload)
        return {
            "status": "success",
            "message": f"Successfully processed and imported {inserted_count} assets."
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))